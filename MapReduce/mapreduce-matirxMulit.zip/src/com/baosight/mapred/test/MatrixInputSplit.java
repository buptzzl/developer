/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.UTF8;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;

public class MatrixInputSplit  extends org.apache.hadoop.mapreduce.InputSplit implements InputSplit{

	public JobConf conf;
	public Path[] elementFiles;
	public int leftColNum;
	public int rightColNum;
	
	public MatrixInputSplit(){}
	
	public MatrixInputSplit(Path[] files, int leftColNum, int rightColNum, JobConf conf){
		this.conf = conf;
		this.elementFiles = files;
		this.leftColNum = leftColNum;
		this.rightColNum = rightColNum;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		// TODO Auto-generated method stub
		
		UTF8.writeString(out, elementFiles[0].toString());
		UTF8.writeString(out, elementFiles[1].toString());
		out.writeInt(leftColNum);
		out.writeInt(rightColNum);
	}

	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		Path file1 = new Path(UTF8.readString(in));
		Path file2 = new Path(UTF8.readString(in));
		elementFiles = new Path[2];
		elementFiles[0] = file1;
		elementFiles[1] = file2;
		leftColNum = in.readInt();
		rightColNum = in.readInt();
	}

	public long getLength(){
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String[] getLocations() {
		// TODO Auto-generated method stub
		return new String[0];
	}

}
