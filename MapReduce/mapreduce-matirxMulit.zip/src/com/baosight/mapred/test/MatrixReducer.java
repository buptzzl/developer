/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;


public class MatrixReducer extends MapReduceBase implements Reducer<ReduceInputKey, DoubleWritable, ReduceInputKey, DoubleWritable>{

	@Override
	public void reduce(ReduceInputKey key, Iterator<DoubleWritable> values,
			OutputCollector<ReduceInputKey,DoubleWritable> output, Reporter reporter)
			throws IOException {
			Double result = 0.0;
			while(values.hasNext()){
				result += values.next().get();
			}
			output.collect(key,new DoubleWritable(result));
	}

}
