/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.io.Text.Comparator;
import org.apache.hadoop.io.file.tfile.ByteArray;

public class ReduceInputKey extends WritableComparator implements WritableComparable{

	int row;
	int col;
	
	
	public ReduceInputKey(){
		super(ReduceInputKey.class);
	}
	
	public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
		System.out.println("Byte array1 length is"+b1.length+"s1 is "+s1+"l1 is "+l1 );
		System.out.println("Byte array2 length is"+b2.length+"s2 is "+s2+"l2 is "+l2 );
		int n1 = WritableUtils.decodeVIntSize(b1[s1]);
		System.out.println("n1 is "+n1);
//		String rowstr1 = new String(b1,s1,n1);
//		String colstr1 = new String(b1,s1+n1,n1);
//		int row1 = Integer.parseInt(rowstr1);
//		int col1 = Integer.parseInt(colstr1);
//		int n2 = WritableUtils.decodeVIntSize(b2[s2]);
//		String rowstr2 = new String(b2,s2,n2);
//		String colstr2 = new String(b2,s2+n2,n2);
//		int row2 = Integer.parseInt(rowstr2);
//		int col2 = Integer.parseInt(colstr2);
//		System.out.println("Row1:"+row1+",col1:"+col1+"; row2:"+row2+",col2:"+col2);
//		if(row1==row2 && col1==col2){
//			return 0;
//		} else{
//			return 1;
//		}
		for(int i  = 0; i< l1;i++){
			if(b1[s1+i] != b2[s2+i]){
				return 1;
			}
		}
		return 0;
	}
	
	@Override
	public int compareTo(Object o) {
		ReduceInputKey other = (ReduceInputKey) o;
		String str1 = ""+this.row+this.col;
		String str2 = ""+other.row+other.col;
		return str1.compareTo(str2);
	}
	
	public int compare(Object o1, Object o2 ){
		String str1 = ""+((ReduceInputKey)o1).row+((ReduceInputKey)o1).col;
		String str2 = ""+((ReduceInputKey)o2).row+((ReduceInputKey)o2).col;
		return str1.compareTo(str2);
	}
	
	public boolean equals(Object o) {
	    if (!(o instanceof ReduceInputKey))
	      return false;
	    ReduceInputKey other = (ReduceInputKey)o;
	    return (this.row == other.row && this.col == other.col);
	  }

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(row);
		out.writeInt(col);
	}

	
	@Override
	public void readFields(DataInput in) throws IOException {
		row = in.readInt();
		col = in.readInt();
	}
	
	public int hashCode(){
		return WritableComparator.hashBytes(getBytes(), getLength());
	}
	
	public String toString(){
		return "";
		//return "row:"+row+", col:"+col;
	}
	
	private byte[] getBytes(){
		String str = ""+row+col;
		return str.getBytes();
	}
	
	private int getLength(){
		String str = ""+row+col;
		return str.getBytes().length;
	}
}
