/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.WritableComparable;

public class MapInputKey implements WritableComparable{
	
	public int leftColNum = 0;
	public int rightColNum = 0;
	
	public MapInputKey(){}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(leftColNum);
		out.writeInt(rightColNum);
		
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		leftColNum = in.readInt();
		rightColNum = in.readInt();
		
	}
	@Override
	public int compareTo(Object o) {
		MapInputKey other = (MapInputKey) o;
		if (this.leftColNum == other.leftColNum
				&& this.rightColNum == other.rightColNum) {
			return 0;
		} else {
			return 1;
		}
	}
	
	public boolean equals(Object o) {
	    if (!(o instanceof MapInputKey))
	      return false;
	    MapInputKey other = (MapInputKey)o;
	    return (this.leftColNum == other.leftColNum && this.rightColNum == other.rightColNum);
	  }
}
