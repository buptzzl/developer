/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.util.LineReader;

public class MatrixInputRecordReader implements RecordReader<MapInputKey,MapInputValue>{

	private JobConf conf;
	public Path[] elementFiles;
	private int leftColNum;
	private int rightColNum;
	private boolean hasnext = true;
	
	
	public MatrixInputRecordReader(JobConf conf, MatrixInputSplit split){
		this.conf = conf;
		this.elementFiles = split.elementFiles;
		this.leftColNum = split.leftColNum;
		this.rightColNum = split.rightColNum;
	}
	
	@Override
	public boolean next(MapInputKey key, MapInputValue value) throws IOException {
		if(!hasnext){
			return hasnext;
		}
		FileSystem fs = elementFiles[0].getFileSystem(conf);
		ArrayList<Double> leftElements = new ArrayList<Double>();
		ArrayList<Double> rightElements = new ArrayList<Double>();
		
		//get left matrix column elements
		FSDataInputStream fileIn = fs.open(elementFiles[0]);
		LineReader reader = new LineReader(fileIn);
		Text newLine = new Text();
		while(reader.readLine(newLine) > 0){
			String strValue = newLine.toString();
			Double doubleValue = Double.parseDouble(strValue);
			leftElements.add(doubleValue);
			newLine = new Text();
		}
		fileIn.close();
		
		//get right matrix column elements
		fileIn = fs.open(elementFiles[1]);
		reader = new LineReader(fileIn);
		newLine = new Text();
		while(reader.readLine(newLine) > 0){
			String strValue = newLine.toString();
			Double doubleValue = Double.parseDouble(strValue);
			rightElements.add(doubleValue);
			newLine = new Text();
		}
		fileIn.close();
		
		if(leftElements.size() > 0 && rightElements.size() > 0){
			key.leftColNum = leftColNum;
			key.rightColNum = rightColNum;
			value.leftMatrixColumn = leftElements;
			value.rightMatrixColumn = rightElements;
			hasnext = false;
			return true;
		}
		hasnext = false;
		return hasnext;
	}

	@Override
	public MapInputKey createKey() {
		return new MapInputKey() ;
	}

	@Override
	public MapInputValue createValue() {
		return new MapInputValue();
	}

	@Override
	public long getPos() throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public float getProgress() throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

}
