/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;



import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class MatrixMulti extends Configured implements Tool{

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new MatrixMulti(), args);
	      System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		JobConf conf = new JobConf(getConf(), MatrixMulti.class);
		conf.setJobName("MatrixMulti");

		conf.setOutputKeyClass(ReduceInputKey.class);
		conf.setOutputValueClass(DoubleWritable.class);
		
		conf.setOutputKeyComparatorClass(ReduceInputKey.class);
		conf.setMapOutputKeyClass(ReduceInputKey.class);
		conf.setMapOutputValueClass(DoubleWritable.class);

		conf.setMapperClass(MatrixMapper.class);
		conf.setCombinerClass(MatrixReducer.class);
		conf.setReducerClass(MatrixReducer.class);

		conf.setInputFormat(MatrixInputFormat.class);
		conf.setOutputFormat(TextOutputFormat.class);

		List<String> other_args = new ArrayList<String>();
		List<String> inputPath = new ArrayList<String>();
		for (int i = 0; i < args.length; ++i) {
			if (args[i].startsWith("left:")) {
				inputPath.add(getAttrValue(args[i]));
			} else if(args[i].startsWith("right:")){
				inputPath.add(getAttrValue(args[i]));
			} else 	if(args[i].startsWith("output:")){
				other_args.add(getAttrValue(args[i]));
			} else if(args[i].startsWith("leftprefix:")){
				conf.set("left.matrix.fileprefix", getAttrValue(args[i]));
			} else if(args[i].startsWith("rightprefix:")){
				conf.set("right.matrix.fileprefix", getAttrValue(args[i]));
			}
		}

		Path[] inputs  = new Path[inputPath.size()];
		int index = 0;
		for(String str : inputPath){
			inputs[index] = new Path(str);
			index++;
		}
		
		FileInputFormat.setInputPaths(conf, inputs);
		FileOutputFormat.setOutputPath(conf, new Path(other_args.get(0)));

		JobClient.runJob(conf);
		return 0;
	}
	
	private String getAttrValue(String str){
		Pattern pattern = Pattern.compile(":");
		String[] values = pattern.split(str, 2);
		return values[1];
	}
}
