/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.IOException;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.InputFormat;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.util.StringUtils;

@SuppressWarnings("rawtypes")
public class MatrixInputFormat implements InputFormat {

	@Override
	public InputSplit[] getSplits(JobConf job, int numSplits)
			throws IOException {
		Path[] dirs = getInputPaths(job);
		if (dirs.length == 2) {
			Path leftMatrixDir = dirs[0];
			Path rightMatrixDir = dirs[1];
			FileSystem fs = leftMatrixDir.getFileSystem(job);
			FileStatus[] leftColumns = fs.listStatus(leftMatrixDir);
			FileStatus[] rightColumns = fs.listStatus(rightMatrixDir);
			int leftMatrixColNum = leftColumns.length;
			int rightMatrixColNum = rightColumns.length;
			String leftMatrixPrefix = job.get("left.matrix.fileprefix");
			String rightMatrixPrefix = job.get("right.matrix.fileprefix");
			
			MatrixInputSplit[] splits = new MatrixInputSplit[leftMatrixColNum * rightMatrixColNum];
			
			int index = 0;
			for(FileStatus leftCol : leftColumns){
				for (FileStatus rightCol : rightColumns){
					String currentLeftColName = leftCol.getPath().getName();
					String currentRightColName = rightCol.getPath().getName();
					int currentLeftColIndex = getIndex(currentLeftColName,leftMatrixPrefix);
					int currentRightColIndex = getIndex(currentRightColName, rightMatrixPrefix);
					Path[] files = new Path[2];
					files[0] = leftCol.getPath();
					files[1] = rightCol.getPath();
					splits[index] = new MatrixInputSplit(files, currentLeftColIndex, currentRightColIndex, job);
					index++;
				}
			}
			return splits;
		}
		return null;
	}

	@Override
	public RecordReader getRecordReader(InputSplit split, JobConf job,
			Reporter reporter) throws IOException {
		return new MatrixInputRecordReader(job, (MatrixInputSplit)split);
	}
	
	public static Path[] getInputPaths(JobConf conf) {
	    String dirs = conf.get("mapred.input.dir", "");
	    String [] list = StringUtils.split(dirs);
	    Path[] result = new Path[list.length];
	    for (int i = 0; i < list.length; i++) {
	      result[i] = new Path(StringUtils.unEscapeString(list[i]));
	    }
	    return result;
	  }

	private int getIndex(String str, String prefix){
		int index = 0;
		String temp = str.replaceAll(prefix, "");
		index = Integer.parseInt(temp);
		return index;
	}
}
