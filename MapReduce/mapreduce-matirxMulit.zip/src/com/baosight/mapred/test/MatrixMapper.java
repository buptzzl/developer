/**
 * Copyright 2012 宝信软件 解决方案事业部
 * 
 * @author 樊后礼   f_houli@163.com    fanhouli@baosight.com
 */
package com.baosight.mapred.test;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class MatrixMapper extends MapReduceBase implements Mapper<MapInputKey,MapInputValue,ReduceInputKey,DoubleWritable>{

	@Override
	public void map(MapInputKey key, MapInputValue value,
			OutputCollector<ReduceInputKey, DoubleWritable> output,
			Reporter reporter) throws IOException {
		
		ArrayList<Double> leftElements = value.leftMatrixColumn;
		ArrayList<Double> rightElements = value.rightMatrixColumn;
		int leftColNum = key.leftColNum;
		int rightColNum = key.rightColNum;
		for(int i = 0; i < leftElements.size();i++){
			Double leftVal = leftElements.get(i);
			Double rightVal = rightElements.get(leftColNum);
			ReduceInputKey tempKey = new ReduceInputKey();
			tempKey.row = i;
			tempKey.col = rightColNum;
//			output.collect(tempKey, new DoubleWritable(leftVal.doubleValue()*rightVal.doubleValue()));
			output.collect(tempKey, new DoubleWritable(leftVal*rightVal));
		}
		
	}

}
